<?php

class ICWP_WPSF_Processor_AuditTrail_Wpsf extends ICWP_WPSF_AuditTrail_Auditor_Base {

	/**
	 */
	public function run() { }
}