<?php

namespace FernleafSystems\Wordpress\Plugin\Shield\Modules\UserManagement;

class UpdateUserPasswordMeta {

	/**
	 * @param
	 */
	public function run() {

		$oQ = new \WP_User_Query();
	}
}