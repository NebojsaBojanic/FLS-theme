<?php

namespace FernleafSystems\Wordpress\Plugin\Shield\Databases\AdminNotes;

use FernleafSystems\Wordpress\Plugin\Shield\Databases\Base;

/**
 * @property string note
 * @property string wp_username
 */
class EntryVO extends Base\EntryVO {
}