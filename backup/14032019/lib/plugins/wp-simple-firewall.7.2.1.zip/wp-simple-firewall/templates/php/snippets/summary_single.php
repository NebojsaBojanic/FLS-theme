<?php
if ( !$enabled ) {
	echo 'All module features disabled.';
	return;
}
?>
Module: Enabled