<p>We need your help to spread the word about Shield Security :)</p>
<p>Talking about us in your WP community, and how effective Shield has been for your site,
   will lend us your invaluable support.</p>
<p>You'll help others find us; help them to trust us; and of course, you'll help build a more secure
	WordPress community.
	<br/><span style="text-decoration: underline">We simply need your help help to reach others</span>...</p>
<p>
	<a href="https://icwp.io/wpsfreview" class="button button-primary" target="_blank">
		Please, could you leave us a review on WordPress.org?</a>
</p>