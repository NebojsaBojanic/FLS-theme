<p>
	<?php echo $strings['notice_message']; ?>
	<br/>- <strong><?php echo $strings['including_message']; ?></strong>
	<br/><?php echo $strings['your_ip']; ?>
</p>