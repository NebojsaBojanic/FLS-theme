<div class="row">
  <div class="span12">
	  <div class="well">
	  	<div class="row">
	  		<div class="span6">
	  			<h3>Love the <?php echo $sPluginName; ?> plugin?</h3>
				<p>Please help <u>spread the word</u> or check out what else we do ...</p>
	  		</div>
	  		<div class="span4">
				<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://www.icontrolwp.com/our-wordpress-plugins/wordpress-simple-firewall-plugin/" data-text="I use the <?php echo $sPluginName; ?> plugin to protect my #WordPress sites!" data-via="iControlWP" data-size="large">Tweet</a><script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
	  		</div>
	  	</div>
		<div class="row">
			<div class="span6">
				<ul>
					<li><a href="https://icwp.io/2b" target="_blank"><strong>Manage <u>All</u> Your WordPress Sites In 1 Place!</strong></a></li>
					<li><a href="https://icwp.io/2c" target="_blank">Check out all our other WordPress Plugins</a></li>
				</ul>
			</div>
			<div class="span5">
				<ul>
					<li><a href="https://icwp.io/2d" target="_blank"><strong>Visit the plugin Help & Support page</strong></a>.</li>
					<li><a href="http://wordpress.org/extend/plugins/wp-simple-firewall/" target="_blank">Show some love, and give this a 5 star rating on WordPress.org.</a></li>
				</ul>
			</div>
		</div>
	  </div><!-- / well -->
  </div><!-- / span12 -->
</div><!-- / row -->
