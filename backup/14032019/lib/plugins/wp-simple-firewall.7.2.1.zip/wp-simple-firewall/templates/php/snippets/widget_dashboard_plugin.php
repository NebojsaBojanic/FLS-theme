<p><?php echo $sInstallationDays; ?></p>
<hr />
<p>
	<?php if ( !empty( $sFooter ) ) : ?>
		<?php echo $sFooter; ?><br />
	<?php endif; ?>
	<span style="font-size: x-small;"><?php echo $sIpAddress; ?></span>
</p>