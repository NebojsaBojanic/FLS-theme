<p>
	<?php echo $strings[ 'not_supported' ]; ?>
	<br /><?php echo $strings[ 'ask_host' ]; ?>
	<br /><?php echo $strings[ 'questions' ]; ?>
	<a href="<?php echo $hrefs[ 'help' ]; ?>" target="_blank"><?php echo $strings[ 'help' ]; ?></a>
</p>