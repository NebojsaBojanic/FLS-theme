<p><strong><a href="<?php echo $hrefs[ 'wizard' ]; ?>" target="_blank">Launch Setup Wizard</a></strong>
	- <?php echo $strings[ 'setup' ]; ?></p>