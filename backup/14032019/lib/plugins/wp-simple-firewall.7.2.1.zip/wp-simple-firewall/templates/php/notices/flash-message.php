<div class="updated odp-admin-notice">
	<p><?php echo $message; ?></p>
</div>