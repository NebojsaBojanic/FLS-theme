<p>
	<?php echo $strings['appears_running_akismet']; ?>&nbsp;
	<br /><strong><?php echo $strings['not_recommended']; ?></strong>
	<a href="<?php echo $hrefs['deactivate']; ?>"><?php echo $strings['click_to_deactivate']; ?></a>
</p>