<h5>What are WordPress Automatic Updates?</h5>
<p>Automatic Updates arrived in WordPress v3.7. Many people believe it's a bad thing, but then may people
also believe the world is flat. You decide.</p>
<p>By default, WordPress only automatically updates minor version upgrades, and translations. Nothing else.</p>
<p>With Shield you can completely disable automatic updates, or even enable it for everything (not recommended).</p>