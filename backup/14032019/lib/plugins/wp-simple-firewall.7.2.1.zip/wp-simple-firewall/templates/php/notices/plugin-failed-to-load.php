<div class="error odp-admin-notice">
	<h3><?php echo $strings['summary_title']; ?></h3>
	<p><?php echo $strings['more_information']; ?></p>
</div>