<p><?php echo $strings['notice_message']; ?>
<br/>&rarr; <?php echo $strings['unlock_link']; ?></p>
<p><?php echo $hrefs['setting_page']; ?></p>