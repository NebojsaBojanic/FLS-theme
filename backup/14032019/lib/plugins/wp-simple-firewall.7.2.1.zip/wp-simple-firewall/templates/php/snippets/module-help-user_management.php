<h5>What is the User Management module?</h5>
<p>WordPress doesn't have user sessions as we like to think of them.</p>
<p>So Shield supplies a 3rd level of user session control to help ensure there isn't any fakery with user logins.</p>
<p>You can see who all is logged in, and from which IP address, and since when.</p>
<p>We will be providing further options for user management in a future release.</p>