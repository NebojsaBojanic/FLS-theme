<p><?php echo $strings['notice_message']; ?></p>
<p><?php echo $hrefs['setting_page']; ?></p>