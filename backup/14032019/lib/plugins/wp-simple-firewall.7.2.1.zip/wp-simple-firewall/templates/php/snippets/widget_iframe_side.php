<iframe name="<?php echo $sWidgetIframeName; ?>"
		src="<?php echo $sWidgetIframeSource; ?>"
		width="<?php echo $sWidgetIframeWidth; ?>"
		height="<?php echo $sWidgetIframeHeight; ?>"
		frameborder="0"
		scrolling="no"
		style="background-color:<?php echo $sWidgetIframeColor; ?>;" ></iframe>