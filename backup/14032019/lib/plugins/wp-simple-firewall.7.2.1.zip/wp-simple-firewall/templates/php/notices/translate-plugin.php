<p>
	<?php echo $strings['like_to_help']; ?>
	<?php echo $strings['head_over_to']; ?> <a href="<?php echo $hrefs['translate']; ?>" target="_blank"> <strong><?php echo $strings['site_url']; ?></a></strong>
</p>